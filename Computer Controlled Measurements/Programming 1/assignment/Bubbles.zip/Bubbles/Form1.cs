﻿using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Bubbles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text Files|*.txt";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader = new StreamReader(openFileDialog1.FileName);

                double threshold = 1.8;
                int holdoff = 30;
                int holdoffCounter = 0;
                int bubbleCount = 0;
                bool inBubble = false;

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    line = line.Trim();
                    if (line == "") continue;

                    string[] parts = line.Split(' ');  // split into 2 columns
                    double value;
                    if (!double.TryParse(parts[1],     // take second column
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out value))
                        continue;

                    if (holdoffCounter > 0)
                    {
                        holdoffCounter--;
                        continue;
                    }

                    if (value < threshold && !inBubble)
                    {
                        bubbleCount++;
                        inBubble = true;
                        holdoffCounter = holdoff;
                    }
                    else if (value >= threshold)
                    {
                        inBubble = false;
                    }
                }

                reader.Close();

                label1.Text = "Bubble count: " + bubbleCount;
            }
        }
    }
}