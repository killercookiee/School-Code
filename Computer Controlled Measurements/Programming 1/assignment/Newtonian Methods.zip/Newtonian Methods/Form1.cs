﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Newtonian_Methods
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(txtA.Text, CultureInfo.InvariantCulture);
            double b = double.Parse(txtB.Text, CultureInfo.InvariantCulture);
            int N = int.Parse(txtN.Text);
            double x = double.Parse(txtX0.Text, CultureInfo.InvariantCulture);

            for (int i = 0; i < N; i++)
            {
                double fx = Math.Sin(x) - a * x - b;
                double fpx = Math.Cos(x) - a;

                if (fpx == 0) break;

                x = x - fx / fpx;
            }

            txtResult.Text = "x = " + x.ToString("F6", CultureInfo.InvariantCulture);
        }



        private void txtA_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSolve_Click(object sender, EventArgs e)
        {

        }
    }
}
